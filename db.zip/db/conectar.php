<?php
	 $db_host = "localhost";
	 $db_name = "ashock";
	 $db_user = "root";
	 $db_pass = "Ashock.2018";
	 try{
		$db_con = new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES  \'UTF8\''));
		$db_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		$db_host = "localhost";
		$db_name = "ashock";
		$db_user = "root";
		$db_pass = "";
		try{
			$db_con = new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES  \'UTF8\''));
			$db_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
		}
		catch(PDOException $e){
			echo "No se puede establecer una conexión con la base de datos por: ".$e;
		}
	}
?>