<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set("America/Bogota"); 
@session_start();

$longitud = $_GET['longitud'];
$latitud = $_GET['latitud'];
if (isset($_SESSION['cedula'])) {
	$cedula=$_SESSION['cedula'];
	$query_users = $db_con->query("SELECT * FROM usuarios WHERE cedula='$cedula'");
	$users = $query_users->fetch(PDO::FETCH_ASSOC);
	$id_user = $users['id_u'];
	
	$fecha = date("Y"). "-".date("m")."-".date("d");
	$hora = date("H").":".date("i").":".date("s");
	$query_locations = $db_con->query("SELECT * FROM geolocalizacion WHERE longitud='$longitud' AND latitud='$latitud'");
	if($query_locations->rowCount() == 0){
		$INSERT = "INSERT INTO geolocalizacion (id_user, longitud, latitud, fecha, hora) VALUES ('$id_user', '$longitud', '$latitud', '$fecha', '$hora')";
		if ($db_con->query($INSERT)){
			1;
			echo $reporte = "Se registró";
		}else{
			echo $reporte = "No se puede registrar";
		}
	}else{
		echo 1;
		//"Tu longitud: ".$longitud."y latitud: ".$latitud;
	}
	/*
	$query_locations = $db_con->query("SELECT * FROM geolocalizacion");
	if($query_locations->rowCount() > 0){
		$UPDATE = 
			"UPDATE geolocalizacion SET 
			longitud='$longitud',
			latitud='$latitud',
			fecha='$fecha',
			hora='$hora'
			WHERE id_user='$id_user';"
		;
		if ($db_con->query($UPDATE)){
			echo 1;
			$reporte = "Se registrar";
		}else{
			$reporte = "No se puede registrar";
		}
	}else{
		$INSERT = "INSERT INTO geolocalizacion (id_user, longitud, latitud, fecha, hora) VALUES ('$id_user', '$longitud', '$latitud', '$fecha', '$hora')";
		if ($db_con->query($INSERT)){
			echo 1;
			$reporte = "Se registró";
		}else{
			$reporte = "No se puede registrar";
		}
	}
	*/
}
		?>