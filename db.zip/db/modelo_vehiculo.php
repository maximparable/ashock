<?php
require("conectar.php");
$d = array();
$id_fabricante = $_GET["id_fabricante"];
$modelo_vehiculo = $db_con->query("SELECT * FROM modelos WHERE id_fabricante=$id_fabricante");
	while($datos = $modelo_vehiculo->fetch(PDO::FETCH_ASSOC)) {
		$id = $datos["id_modelo"];
		$modelo = $datos['modelo'];
    	$d[$id] = $modelo;
	}
print_r(json_encode($d));
?>