<?php
require("conectar.php");
$usuario = $_POST['usuario'];
$contrasena = md5($_POST['clave']);
	$login_user = $db_con->query("SELECT * FROM usuarios WHERE correo='$usuario'");
	if($login_user->rowCount() > 0){
		$login_passwd = $db_con->query("SELECT * FROM usuarios WHERE contrasena='$contrasena'");
		if($login_passwd->rowCount() > 0){
			$user = $login_passwd->fetch(PDO::FETCH_ASSOC);
			@session_start();
			$_SESSION['cedula']=$user['cedula'];
			echo "1";
		}else{
			echo "El usuario y contraseña no coincide.";
		}
	}else{
		echo "El usuario no se encuentra en nuestra base de datos.";
	}
?>