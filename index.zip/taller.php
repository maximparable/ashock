<!DOCTYPE html>
<html>
	<head>

		<title>Ashock</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="description" content="By MCDeveloper." />
		<meta name="keywords"  content="key1,key1,key1" />
		<meta name="Resource-type" content="Document" />
		<meta name="author" content="mcdeveloper" />

		<?php
		require("db/conectar.php");
		require("db/consulta_usuario.php");
		require("ext/styles.php");
		require("ext/scripts.php");
		include_once('functions.php');
		?>
		<link rel="stylesheet" type="text/css" href="ext/css/jcalender.css">
		<link rel="stylesheet" type="text/css" href="css/recurso-style.css">
		<script type="text/javascript" src="ext/js/dashboard.js"></script>
		<script type="text/javascript" src="js/recurso-script.js"></script>
		
	</head>
	<body>
		<div id="wrapper">
			<div class="overlay"></div>
			<!-- Sidebar -->
			<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">				
				<ul class="nav sidebar-nav">
					<li class="sidebar-brand" style="background: #FFF url(<?php if($login==1) { echo $foto_taller; } ?>) no-repeat; background-size: cover;">
						<a id="historia" href="#"><p><?php if($login==1){echo $correo;} ?></p></a>
					</li>
					<li>
						<a id="historia" href="#"><b>Nombre del Taller: </b><p><?php if($login==1){echo $empresa;} ?></p></a>
					</li>
					<li>
						<a id="historia" href="#"><b>Dirección: </b><p><?php if($login==1){echo $direccion;} ?></p></a>
					</li>
					<li>
						<a id="historia" href="#"><b>Horarios de Atención: </b><p><?php if($login==1){echo date("g:i a",strtotime($hora_abierto))." a ".date("g:i a",strtotime($hora_cerrado));} ?></p></a>
					</li>
					<li>
						<a id="historia" href="#"><b>Días de Atención: </b><p><?php if($login==1){echo $dias_atencion;} ?></p></a>
					</li>
					<li>
						<a class="cerrar" href="#">Cerrar sesión</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;">
						<img src="img/logo.png" width="45%" alt="">
					</center>
					<h4 align="center">Ashock</h4>
				</ul>
			</nav>
			<!-- /#sidebar-wrapper -->
			<!-- Page Content -->
			<div id="page-content-wrapper">
				<div id="home" style="background: #FFFFFF">
					<header>
						<div class="header-top clearfix">
							<a class="l-left toggle-menu" href="#">
								<button type="button" class="hamburger is-closed" data-toggle="offcanvas">
									<span class="hamb-top"></span>
									<span class="hamb-middle"></span>
									<span class="hamb-bottom"></span>
								</button><img style="margin-left: 80px" src="img/logo_dash.png" height="40" alt="">
							</a>
							<ul class="nav navbar-nav menus pull-right">
								<li class="nav navbar-nav menus dropdown" style="margin-left: -80px;">
									<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" style="color: #FCF0F1">
									<h4>Admin <span class="caret"></span></h4></a>
									<ul class="dropdown-menu" style="margin-left: -50px;">
										<li><a href="#">Mi Cuenta (editar)</a></li>
										<li role="separator" class="divider"></li>
										<li class="cerrar"><a href="#">Cerrar Sesión</a></li>
									</ul>
								</li>
							</ul>
						</div>
					</header>
					<div id="auto-taller">
						<div class="" style="padding: 10px 100px;">
							<h2>Mapa Auto taller 
								<span class="fa fa-plus" style="background: #006DAA; color: #FFFFFF; border-radius: 100%; padding: 15px; float: right"></span>
							</h2><br>
							<p>Busqueda  de usuarios</p>
							<form class="navbar-form">
								<input type="text" class="form-control" placeholder="Buscar" style="border: 1px solid #999; width: 50% !important">
								<br><br>
								<button type="button" class="btn btn-succes">Buscar</button>
							</form><br>
							<p>Todos los usuarios </p>
							<div class="col-sm-12 col-md-12 col-lg-12" style="border: 2px solid #888; border-radius: 5px; padding-bottom: 20px; height: 660px">
								<!-- Display event calendar -->
								<div id="calendar_div" style="padding: 5px">
									<?php echo getCalender(); ?>
								</div><br><br><br><br>
									<!-- Display event calendar -->
							</div>
							<div class="col-sm-12 col-md-12 col-lg-12" style="padding: 5px">
								<div class="chating" style="border: 2px solid #888; border-radius: 5px; padding: 0px;">
									<div class="headchat" style="background: #F9F9F9; padding: 8px 12px; height: 60px; border: 1px solid #999999;">
										<div class="col-lg-4"><h4 align="center">Carro taller</h3></div>
										<div class="col-lg-4"><h4 align="center">Cliente</h3></div>
										<div class="col-lg-4"><h4 align="center">Hora y Fecha</h3></div>
									</div>
									<div class="bodycchat" style="padding:30px;">
										<div class="row" style="padding:0px;margin:0px">
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Taller Norte</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Pepito Perez</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">26-Jul 18-4:30 pm</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="right" class="fa fa-circle" style="position: relative;color: #00FF00;padding: 3px;float: right;top: 6px;"></p> 
												<span class="editar" style="float: right; color: #FF7043; margin-top: 4px">Editar</span>
											</div>
										</div>
										<div class="row" style="padding:0px;margin:0px">
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Taller Norte</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Pepito Perez</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">26-Jul 18-4:30 pm</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="right" class="fa fa-circle" style="position: relative;color: #00FF00;padding: 3px;float: right;top: 6px;"></p> 
												<span class="editar" style="float: right; color: #FF7043; margin-top: 4px">Editar</span>
											</div>
										</div>
										<div class="row" style="padding:0px;margin:0px">
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Taller Norte</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">Pepito Perez</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="center">26-Jul 18-4:30 pm</p>
											</div>
											<div class="col-lg-3" style="background: #EFEDED; padding: 5px 10px; border-radius: 5px; border:1px solid #fff">
												<p align="right" class="fa fa-circle" style="position: relative;color: #00FF00;padding: 3px;float: right;top: 6px;"></p> 
												<span class="editar" style="float: right; color: #FF7043; margin-top: 4px">Editar</span>
											</div>
										</div><br><br><br><br><br><br><br><br><br><br><br><br>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
   	 <script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>
	</body>
</html>
