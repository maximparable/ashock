<!DOCTYPE html>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=gb18030">
	
		<title>Ashock</title>

		
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="description" content="By MCDeveloper." />
		<meta name="keywords"  content="key1,key1,key1" />
		<meta name="Resource-type" content="Document" />
		<meta name="author" content="mcdeveloper" />

		<?php
		require("db/conectar.php");
		require("db/consulta_usuario.php");
		require("ext/styles.php");
		require("ext/scripts.php");
		?>
		
	</head>
	<body>
		<div id="wrapper">
			<div class="overlay"></div>
			<!-- Sidebar -->
			<nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">				
				<ul class="nav sidebar-nav">
					<li class="sidebar-brand" style="background: #000 url(<?php if($login==1) { echo $foto_frontal; } ?>) no-repeat; background-size: cover;">
						<img src="<?php if($login==1){echo $foto_perfil;} ?>" class="img-circle" width="67" alt="">
						<p><?php if($login==1){echo $correo;} ?></p>
					</li>
					<li>
						<a id="micuenta" href="#Micuenta">Mi cuenta</a>
					</li>
					<li>
						<a id="historia" href="#">Historial</a>
					</li>
					<li>
						<a class="ayuda" href="#">Ayuda</a>
					</li>
					<li>
						<a class="cerrar" href="#">Cerrar sesión</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;">
						<img src="img/logo.png" width="45%" alt="">
					</center>
					<h4 align="center">Ashock</h4>
				</ul>
			</nav>
			<!-- /#sidebar-wrapper -->
			<!-- Page Content -->
			<div id="page-content-wrapper">
				
				<div id="home">
					<header>
						<div class="header-top clearfix">
							<a class="l-left toggle-menu" href="#">
								<button type="button" class="hamburger is-closed" data-toggle="offcanvas">
									<span class="hamb-top"></span>
									<span class="hamb-middle"></span>
									<span class="hamb-bottom"></span>
								</button>
							</a>
						</div>
					</header>
					<div id="fullpage">
					
						<div id="map"></div>
						<script>
						function initMap() {
						        var map = new google.maps.Map(document.getElementById('map'), {
						          center: {lat: 4.677424, lng: -74.048205},
						          zoom: 17
						        });
						        var DivMap = document.getElementById('map');
						        if (navigator.geolocation) {
						          navigator.geolocation.getCurrentPosition(function(position) {
						           
								lat=position.coords.latitude;
								lon=position.coords.longitude;
		
								var Glatlon = new google.maps.LatLng( lat, lon );
		
								var ConfigMap = {
									zoom: 18,
									center: Glatlon
								};
								
								var GMap = new google.maps.Map( DivMap, ConfigMap );
								
								var Grua1 = {
									position: Glatlon,
									map: GMap,
									title: "eres tu",
									fillOpacity: .9,
									animation: google.maps.Animation.DROP
								};							
								var IconGrua1 = new google.maps.Marker( Grua1);
								IconGrua1.setIcon( "img/icons/grua.png" );
								
						          }, function() {
						            handleLocationError(true, infoWindow, map.getCenter());
						          });
						        }else{
						        	alert("sin gps");
						        }
						           
						
							/*
							var Grua1 = {
								position: {lat: 4.675324, lng: -74.048895},
								map: map,
								title: "eres tu",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};							
							var IconGrua1 = new google.maps.Marker( Grua1);
							IconGrua1.setIcon( "img/icons/grua.png" );
							var Grua2 = {
								position: {lat: 4.677494, lng: -74.049965},
								map: map,
								title: "eres tu",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};							
							var IconGrua2 = new google.maps.Marker( Grua2);
							IconGrua2.setIcon( "img/icons/grua.png" );
							
							var Grua3 = {
								position: {lat: 4.677494, lng: -74.049165},
								map: map,
								title: "eres tu",
								fillOpacity: .9,
								animation: google.maps.Animation.DROP
							};
							
							var IconGrua3 = new google.maps.Marker( Grua3);
							IconGrua3.setIcon( "img/icons/grua.png" );
						*/
						}
						</script>
		    				<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVHQ-vbUvaGZQUx5MweCwlE8oMwVieIAw&callback=initMap" async defer></script>
					
					</div>
					<footer class="desktop">
						<h6 align="center">
							<img id="grua_u" src="img/icon3.png" alt="grua">
						</h6>
					</footer>
				</div>
				
			</div>		
		</div>
		<script type="text/javascript" src="https://ashock.app:3000/socket.io/socket.io.js"></script>
	</body>
		<script type="text/javascript" src="ext/js/dasboard-maps.js"></script>
</html>
