<?php
//db details
$dbHost = 'localhost';
$dbUsername = 'virtuale_root';
$dbPassword = 'Ashock.2018';
$dbName = 'virtuale_ashock';

//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>