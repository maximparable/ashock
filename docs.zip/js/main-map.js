var map, infoWindow;
var DivMap = document.getElementById('map');
// JavaScript Document
function initMap(){
	var socket = io.connect('https://ashock.app:3000');
	map = new google.maps.Map(document.getElementById('map'),{
          center: {lat: 4.5783445, lng: -74.0768145},
          zoom: 16
	});

        infoWindow = new google.maps.InfoWindow;
        // Try HTML5 geolocation.
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
           
		lat=position.coords.latitude;
		lon=position.coords.longitude;
		
		var Glatlon = new google.maps.LatLng( lat, lon );
		
		var ConfigMap = {
			zoom: 18,
			center: Glatlon
		};
		
		var GMap = new google.maps.Map( DivMap, ConfigMap );
		var longitud=lon;
		var latitud=lat;
		var registrar = setInterval(registrarcadaminuto, 10000);  
		function registrarcadaminuto() {
		$.ajax({
			url  : 'db/ubicaciones.php?longitud='+longitud+'&latitud='+latitud,
			beforeSend : function(){
			},
			success : function(response){
				if(response!=1){
				//	alert(response);
				}
		   }
		 });	
		}
		//---------------------- TU ----------------------//
		var ConfigIconUser = {
			position: Glatlon,
			map: GMap,
			title: "eres tu",
			fillOpacity: .9,
			animation: google.maps.Animation.DROP
		};
		
		var IconUser = new google.maps.Marker( ConfigIconUser );
			IconUser.setIcon( "img/icons/car.png" );
			
		
		// ---------------------------------------------------------- //
			
			
          }, function() {
            handleLocationError(true, infoWindow, map.getCenter());
          });
        } else {
          // Browser doesn't support Geolocation
          handleLocationError(false, infoWindow, map.getCenter());
        }
};
      function handleLocationError(browserHasGeolocation, infoWindow, pos) {
        infoWindow.setPosition(pos);
        infoWindow.setContent(browserHasGeolocation ?
			'Error: The Geolocation service failed.' :
        	'Error: Your browser doesn\'t support geolocation.');
        infoWindow.open(map);
      }
      