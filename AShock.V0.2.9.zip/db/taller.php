<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
date_default_timezone_set("America/Bogota");

$starDate = new DateTime('2018-06-01');
$endDate = new DateTime('2018-06-30');

/*
while( $starDate <= $endDate){
	if($starDate->format('l')== 'Saturday' || $starDate->format('l')== 'Sunday'){
		echo $starDate->format('y-m-d (D)')."<br/>";
	}
	$starDate->modify("+1 days");
}

$var= date("w");
if($var == "0" ){
	echo "Es domingo";
} else if ($var == "1" ) {
	echo "Es Lunes";
} else if ($var == "2" ) {
	echo "Es Martes";
} else if ($var == "3" ) {
	echo "Es Miercoles";
} else if ($var == "4" ) {
	echo "Es Jueves";
} else if ($var == "5" ) {
	echo "Es Viernes";
} else if ($var == "6" ) {
	echo "Es Sabado";
}
*/
	$id_perfil = $_POST['id_perfil'];
	$nit = $_POST['nit'];
	$empresa = $_POST['empresa'];
	$direccion = $_POST['dir_empresa'];
	$correo = $_POST['correo_empresa'];
	$contrasena = $_POST['contra_empresa'];
	$contrasena = md5($contrasena);
	$telefono = $_POST['telefono_empresa'];
	//$placa = $_POST['placa'];
	//$id_tipo_car = $_POST['tipo_vehiculo'];
	$id_tipo_car = "";
	$estado = "activo";

	$fecha = date("Y"). "-".date("m")."-".date("d");
	$hora = date("H").":".date("i").":".date("s");

$reporte = "error ";
if ($_FILES['imagen_taller']['size']>0) {
	$file = $_FILES["imagen_taller"];
	$nombre = $file["name"];
	$array_nombre = explode('.',$nombre);
	$cuenta_arr_nombre = count($array_nombre);
	$extension = strtolower($array_nombre[--$cuenta_arr_nombre]);
	$foto = time().'_'.rand(0,99999).'.'.$extension;
    $foto_perfil = "./img/vehiculos/talleres/".$foto;
}else{$foto_perfil = "./img/vehiculos/talleres/sin_foto.png";}


	$error1=0;
	$error2=0;
/*	$INSERT_carros = "INSERT INTO carros (placa, id_tipo_car, id_fabricante, id_modelo, id_ano, foto_frontal, foto_derecha, foto_izquierda, foto_trasera)
	VALUES ('$placa', $id_tipo_car, $id_fabricante, $id_modelo, $id_ano, '$foto_frontal', '$foto_derecha', '$foto_izquierda', '$foto_trasera')"; */
	
	$id_car = 0;
	/*if ($db_con->query($INSERT_carros)){
		$error1=1;
		$query_carros = $db_con->query("SELECT * FROM carros ORDER BY id_car DESC");
		$carros = $query_carros->fetch(PDO::FETCH_ASSOC);
		$id_car = $carros['id_car'];
	}else{
		$id_car = 0;
		$reporte = "no se puede registrar su carro";
	}*/

	$INSERT_users = "INSERT INTO usuarios (id_u, id_car, id_perfil, cedula, telefono, nombres, apellidos, correo, contrasena, foto_perfil, estado, fecha, hora) 
	VALUES (NULL, 1, '$id_perfil', '$nit', '$telefono', '$empresa', '$direccion', '$correo', '$contrasena', '$foto_perfil', '$estado', '$fecha', '$hora')";
	if ($db_con->query($INSERT_users)){
		@session_start();
		move_uploaded_file($file["tmp_name"], "../img/vehiculos/talleres/".$foto);
		$_SESSION['cedula'] = $nit;
		echo 1;
	}else{
		echo 'Error '.$reporte;
	}
?>