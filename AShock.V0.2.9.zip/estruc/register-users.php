					<div id="register1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente1"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br><br><br>
							<div class="form-group">
								<p align="center">
									<label for="imagen1" style="cursor: pointer">
										<img id="foto1" src="img/perfil/users/subir_foto.png" width="92" alt="">
									</label>
									<input id="imagen1" type="file" name="foto_perfil" style="display: none; cursor: pointer !important;">
								</p>
								<input type="number" class="form-control" id="id_perfil" name="id_perfil" value="3" style="display: none">
							</div>
							<div class="form-group">
								<label class="control-label" for="cedula">Cédula *</label>
								<input type="number" class="form-control" placeholder="00000000" id="cedula" name="cedula" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="placa">Placa *</label>
								<input type="text" name="placa" placeholder="ABC-123" class="form-control" id="placa">
							</div>
							<div class="form-group">
								<label class="control-label" for="nombres">Nombres *</label>
								<input type="text" class="form-control" placeholder="Pepito" id="nombres" name="nombres" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="apellidos">Apellidos *</label>
								<input type="text" class="form-control" placeholder="Perez" id="apellidos" name="apellidos" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="correo">Correo Electrónico *</label>
								<input type="text" class="form-control" id="correo" name="correo" autocomplete="off" value="" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="contrasena">Contraseña *</label>
								<input type="password" class="form-control" id="contrasena" name="contrasena" autocomplete="off" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="telefono">Numero de contacto *</label>
								<input type="number" class="form-control" id="telefono" name="telefono" required>
							</div>
							<button id="siguiente1" type="button" class="btn btn-warning btn-big siguiente1">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar1" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="register2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente2"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<br><br><br>
							<div class="form-group">
								<label class="control-label" for="tipo_vehiculo">Tipo de Vehículo*</label>
								<select id="tipo_vehiculo" name="tipo_vehiculo" class="form-control">
									<option value="0">Seleccionar uno</option>
								</select>
							</div>
							<div class="form-group">
								<label class="control-label" for="fabricante">Fabricante del Vehículo*</label>
								<select id="fabricante" name="fabricante" class="form-control">
									<option value="0">Seleccionar uno</option>
								</select>
							</div>
							<div class="form-group">
								<label class="control-label" for="modelos">Modelo del Vehículo *</label>
								<select id="modelos" name="modelos" class="form-control">
									<option value="0">Seleccionar uno</option>
								</select>
							</div>
							<div class="form-group">
								<label class="control-label" for="anos">Año de Fabricación  del vehículo *</label>
								<select id="anos" name="anos" class="form-control">
									<option value="0">Seleccionar uno</option>
								</select>
							</div>
							<button id="siguiente2" type="button" class="btn btn-warning btn-big siguiente2">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar2" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="register3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente3"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br>
							<div class="form-group">
								<label class="control-label" for="">Fotografía vista frontal del vehículo *</label><br/>
								<label for="imagen2" style="cursor: pointer">
									<img id="foto2" src="img/vehiculos/frontal.png" alt="">
								</label>
								<input id="imagen2" type="file" name="foto_frontal" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía perfil lateral derecho *</label><br/>
								<label for="imagen3" style="cursor: pointer">
									<img id="foto3" src="img/vehiculos/derecho.png" alt="">
								</label>
								<input id="imagen3" type="file" name="foto_derecha" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="imagen4">Fotografía vista trasera del vehículo *</label><br/>
								<label for="imagen4" style="cursor: pointer">
									<img id="foto4" src="img/vehiculos/trasero.png" alt="">
								</label>
								<input id="imagen4" type="file" name="foto_izquierda" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="foto5">Fotografía perfil lateral izquierdo *</label><br/>
								<label for="imagen5" style="cursor: pointer">
									<img id="foto5" src="img/vehiculos/izquierdo.png" alt="">
								</label>
								<input id="imagen5" type="file" name="foto_trasera" style="display: none; cursor: pointer !important;">
							</div>
							<button id="siguiente3" type="button" class="btn btn-warning btn-big siguiente3">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar3" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="register4" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px" class="fa fa-check l-right siguiente4"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<p align="center">
								<input type="checkbox" id="c2" class="c2" required>
								<label for="c2"><span></span> Acepto los <a href="">Términos y condiciones</a></label> debes ver las 
								<label ><a href="">Política de privacidad</a></label>
								<div id="error" class="error"></div>
							</p>
							<button id="guardar" class="btn btn-warning btn-big" type="submit">Aceptar</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar4" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>