					<div id="grua1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente1"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br><br>
							<div class="form-group">
								<p align="center">
									<label for="perfil_grua" style="cursor: pointer">
										<img id="foto_perfil" src="img/perfil/users/subir_foto.png" width="92" alt="">
									</label>
									<input id="perfil_grua" type="file" name="perfil_grua" style="display: none; cursor: pointer !important;">
								</p>
								<input type="number" class="form-control" name="id_perfil" value="5" style="display: none">
							</div>
							<div class="form-group">
								<label class="control-label" for="cedula">Cédula *</label>
								<input type="number" class="form-control" placeholder="00000000" name="cedula_grua" id="cedula_grua" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="nombres_grua">Nombres *</label>
								<input type="text" class="form-control" placeholder="Pepito" name="nombres_grua" id="nombres_grua" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="apellidos_grua">Apellidos *</label>
								<input type="text" class="form-control" placeholder="Perez" name="apellidos_grua" id="apellidos_grua" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="telefono_grua">Numero de contacto *</label>
								<input type="number" class="form-control" name="telefono_grua" id="telefono_grua" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="correo">Correo Electrónico *</label>
								<input type="text" class="form-control" name="correo_grua" autocomplete="off" value="" id="correo_grua" required>
							</div>
							<div class="form-group">
								<label class="control-label" for="contrasena">Contraseña *</label>
								<input type="password" class="form-control" id="contra_grua" name="contra_grua" id="contrasena_grua" required>
							</div>
							<button id="siguiente_grua1" type="button" class="btn btn-warning btn-big siguiente1">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_grua1" class="l-left regresar1" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="grua2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Grúa 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente2"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<br><br>
							<div class="form-group">
								<label class="control-label">Fotografia Grúa*</label>
								<label for="imagen_grua" style="cursor: pointer; width: 100% !important;">
									<img id="foto_grua" src="img/vehiculos/gruas/sin_grua.png" width="100%" alt="">
								</label>
								<input id="imagen_grua" type="file" name="foto_grua" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="tipo_vehiculo_grua">Tipo de Grúa*</label>
								<input type="text" name="tipo_vehiculo_grua" placeholder="Carga" class="form-control" id="tipo_vehiculo_grua">
							</div>
							<div class="form-group">
								<label class="control-label" for="placa_grua">Matricula del vehículo*</label>
								<input type="text" name="placa_grua" placeholder="ABC-123" pattern="[a-z]{1,15}" class="form-control" id="placa_grua">
							</div>
							<button id="siguiente_grua2" class="btn btn-warning btn-big siguiente2" type="button">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_grua2" class="l-left regresar2" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="grua3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px" class="fa fa-check l-right siguiente4"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<p align="center">
								<input type="checkbox" id="g3" class="c3" required>
								<label for="c3"><span></span> Acepto los <a href="">
								Términos y condiciones</a></label> debes ver las 
								<label ><a href="">Política de privacidad</a></label>
							</p>
							<div id="error_grua" class="error"></div>
							<button id="guardar_grua" class="btn btn-warning btn-big" type="submit">Aceptar</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar_grua3" class="l-left regresar3" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>