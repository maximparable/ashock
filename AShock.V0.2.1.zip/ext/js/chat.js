$(document).ready(function() {
// JavaScript Document
	'use strict';
	var socket = io.connect('https://assistanceshock.com:3000');
	
	var sms = document.getElementById("audio");
	
	var username = document.getElementById("chatcorreo");
	var foto = $("#chatfoto_perfil").val();
	var message = document.getElementById("message");
	/*
	var nombres = document.getElementById('chatnombres');
	var apellidos = document.getElementById('chatapellidos');
	//var nombrecompleto = nombres.value+" "+apellidos.value;
	
	
var dt = new Date();
var month = dt.getMonth()+1;
var day = dt.getDate();
var year = dt.getFullYear();
//var dateTime = month + '-' + day + '-' + year;
*/
	function chat(){
		socket.emit('chatsend:message', {
			username: username.value,
			message: message.value,
			foto: foto
		});
		$("#message").val("");
	}
	
var count = 1;
socket.on('chatget:message', function (data) {
		if(username.value === data.username){
			var send_message =
				'<p id="sms'+count+'" align="right">'+
					'<div class="send_message" style="">'+data.message+'</div>'+
					'<img src="'+foto+'" width="45" style="position: relative; top: -67px; float: left;" alt="">'+
				'</p>';
			$("#fullpage2").append(send_message);
			count++;
			location.href="#sms"+count;
		}else{
			var get_message =
				'<p id="sms'+count+'" align="left">'+
					'<div class="get_message">'+data.message+'</div>'+
				'</p>';
			sms.play();
			$("#fullpage2").append(get_message);
			count++;
			location.href="#sms"+count;
		}
});
	
	
	socket.on('query:user', function(dato) {
		$("#chatusername").text(dato.nombrecompleto);
		$("#chatfoto").attr("src",dato.foto);
	});
	$(".fa-send").click(function(){
		if ($("#message").val() != "") {
			chat();
		}	
	});
	$("#message").focus(function () {
		$("#message").keypress(function (e) {
			if (e.which === 13) {
				if ($("#message").val() != "") {
					chat();
				}
			}
		});
	});
	$("#message").keyup(function(){
		socket.emit('chat:writing', {
			username: username.value,
			foto: foto
		});
	});
	socket.on('chat:writing', function(dato) {
		$("#chatusername").text(dato.username);
		$("#chatfoto").attr("src",dato.foto);
		$("#estado").text(' esta escribiendo...');
		setTimeout(function(){
			$("#estado").text('');
		},2000);
	});
	
	/*
	function chat_up_file(evt) {
		var files = evt.target.files;
		for (var i = 0, f; f = files[i]; i++) {
			if (!f.type.match('image.*')) { continue; }
			var reader = new FileReader();
			reader.onload = (function() {
				return function(e) {
					var send_img =	
						'<p align="left">'+
							'<div class="send_message"><img src="'+e.target.result+'" width="100%" alt=""></div>'+
					'<img src="img/logo.png" width="45" style="position: relative; top: -67px; float: left;" alt="">'+
						'</p>';
					$("#fullpage2").append(send_img);
				};
			})(f);
			reader.readAsDataURL(f);
		}
	}
	$('#chat_up_file').change(chat_up_file);
	*/
	
});