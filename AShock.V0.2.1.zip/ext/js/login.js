$(document).ready(function() {
// JavaScript Document
	'use strict';
	var logined = $("#logined").val();
	if(logined==1){
		$("#register-login").addClass("hidden");
		$("#home").removeClass("hidden");
		$("#page").attr("src","./estruc/maps/index.html");
	}
	/*
  $("#entrar").click(function () {
	$("#login").addClass("hidden");
	$("#home").removeClass("hidden");
	$("#page").attr("src","maps/index.html");
  });*/
	/*
	*/function logear(){
		var formData = new FormData($("#logear")[0]);
		$.ajax({
			url  : 'db/login.php',
			type : 'POST',
			contentType: false,
			processData: false,
			data: formData,
			beforeSend: function(){
				$(".login_response").fadeOut();
				$(".login_response").fadeIn(100, function(){
					$(".login_response").html('');
					$(".login_response").html('<div class="alert alert-warning" role="alert"> Cargando ... </div>');
				});
			},
			success : function(response){
				if(response==="1"){
					$("#register4").addClass("hidden");
					$("#home").removeClass("hidden");
					$("#page").attr("src","./estruc/maps/index.html");
					location.href='index.php';
				}else{
					$("#btn-login").html('Error');
					$(".login_response").fadeIn(100, function(){
						$(".login_response").html('');
						$(".login_response").html('<div class="alert alert-danger" role="alert"> '+response+' </div>');
					});
				}
		   }
		});
		return false;
	}
	$("#entrar").click(function(){
		logear();
	});
	$(".siguiente4").click(function(){
		logear();
	});
});