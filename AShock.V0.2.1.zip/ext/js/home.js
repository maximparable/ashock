$(document).ready(function() {
	"use strict";
	
	
	var video = document.getElementById("myVideo");
	var vol = 0;
	
	setTimeout(function(){
		$("#texto").animate({opacity: 0},1000);
	},5000);
	setTimeout(function(){
		$("#texto").text("Click en el cohete para ver Reel");
		$("#texto").animate({opacity: 1},1000);
	},6000);
		
  $(".reel a").on('click', function() {
	  SoundOf();
  });
  $(".close").on('click', function() {
	  if(vol===0) {
		  vol=0;
		  SoundOn();
	  }else{
		  vol=1;
		  SoundOf();
	  }
  });
  $("#volumen").on('click', function() {
	  if(vol===0) {
		  vol=1;
		  SoundOf();
	  }else{
		  vol=0;
		  SoundOn();
	  }
  });
function SoundOn() {
	video.volume =1;
	$("#volumen").removeClass("fa-volume-off");
	$("#volumen").addClass("fa-volume-up");
}
function SoundOf() {
	video.volume =0;
	$("#volumen").removeClass("fa-volume-up");
	$("#volumen").addClass("fa-volume-off");
}
////////////////////////////////////////////////////////////////////////////////////////	
	
	
	
});