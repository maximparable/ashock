<?php
require("conectar.php");
$usuario = $_POST['usuario'];
$contrasena = md5($_POST['clave']);
	$login_user = $db_con->query("SELECT * FROM users WHERE correo='$usuario' AND contrasena='$contrasena'");
	if($login_user->rowCount() > 0){
		$user = $login_user->fetch(PDO::FETCH_ASSOC);
		@session_start();
		$_SESSION['cedula']=$user['cedula'];
		echo "1";
	}else{
		echo "Error de usuaro o contraseña";
	}
?>