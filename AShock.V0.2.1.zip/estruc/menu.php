				<ul class="nav sidebar-nav">
					<li class="sidebar-brand" style="background: url(<?php if($login==1) { echo $foto_izquierda; } ?>) no-repeat; background-size: cover;">
						<img src="<?php if($login==1){echo $foto_perfil;} ?>" class="img-circle" width="67" alt="">
						<p><?php if($login==1){echo $correo;} ?></p>
					</li>
					<li>
						<a id="micuenta" href="#Micuenta">Mi cuenta</a>
					</li>
					<li>
						<a id="historia" href="#">Historial</a>
					</li>
					<li>
						<a class="ayuda" href="#">Ayuda</a>
					</li>
					<li>
						<a class="cerrar" href="#">Cerrar sesión</a>
					</li>
					<hr width="100%"><br>
					<center style="clear:both;"><img src="img/logo.png" width="45%" alt=""></center>
					<h4 align="center">Assistance Shock</h4>
					<!--
					<li class="dropdown">
					  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Works <span class="caret"></span></a>
					  <ul class="dropdown-menu" role="menu">
						<li class="dropdown-header">Dropdown heading</li>
						<li><a href="#">Action</a></li>
					  </ul>
					</li>
					-->
				</ul>