		<link rel="icon" href="./favicon.ico" type="image/x-icon">
		<link href="./ext/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<link rel="stylesheet" type="text/css" href="ext/css/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/estructure.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/style.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/responsive.css" />


  <style type="text/css">
	#map{
      height: 92%;
    }
	.menu-micuena{
		margin: auto;
		list-style: none;
		display: inline-flex;
    }
	.menu-micuena li{
		margin-left: 5px;
		margin-right: 10px;
		cursor: pointer;
    }
	.menu-micuena li:hover{
		color: #2095F2;
    }
	.time{
		width: 75px;
		text-align: center;
		background-color: #fff;
		background-image: none;
		border: 1px solid #ccc;
		border-radius: 4px;
	}
	.time:focus{
		outline: none;
	}
	  .dropdown a {
		  background: transparent !important;
	  }
	  .dropdown a:hover {
		  background: transparent !important;
	  }
	  button {
		  color: #FFFFFF;
	  }
  </style>