		<link rel="icon" href="../favicon.ico" type="image/x-icon">
		<link href="./ext/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<link rel="stylesheet" type="text/css" href="ext/css/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/estructure.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/style.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/responsive.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/slick.css">
		<link rel="stylesheet" type="text/css" href="ext/css/slick-theme.css">


  <style type="text/css">
    .slider {
        width: 50%;
        margin: 100px auto;
    }

    .slick-slide {
      margin: 0px 20px;
    }

    .slick-slide img {
      width: 100%;
    }

    .slick-prev:before,
    .slick-next:before {
      color: black;
    }


    .slick-slide {
      transition: all ease-in-out .3s;
      opacity: .2;
    }
    
    .slick-active {
      opacity: .5;
    }

    .slick-current {
      opacity: 1;
    }
  </style>