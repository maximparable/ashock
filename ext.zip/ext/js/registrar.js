$(document).ready(function() {
// JavaScript Document
	'use strict';
	
	$.getJSON('db/tipo_vehiculo.php',function(tipo_vehiculo){
		$.each(tipo_vehiculo, function(id,tipo){
			$("#tipo_vehiculo").append('<option value="'+id+'">'+tipo+'</option>');
		});
	});
	$.getJSON('db/fabricante_vehiculo.php',function(fabricante_vehiculo){
		$.each(fabricante_vehiculo, function(id,fabricante){
			$("#fabricante").append('<option value="'+id+'">'+fabricante+'</option>');
		});
	});
	$("#fabricante").change(function() {$("#modelos").html('');
		$.getJSON('db/modelo_vehiculo.php?id_fabricante='+$("#fabricante").val(),function(modelos){
			$.each(modelos, function(id,modelo){
				$("#modelos").append('<option value="'+id+'">'+modelo+'</option>');
			});
		});
    });
	$.getJSON('db/ano_vehiculo.php',function(anos_vehiculo){
		$.each(anos_vehiculo, function(id,ano){
			$("#anos").append('<option value="'+id+'">'+ano+'</option>');
		});
	});
	
	
	$("#guardar").click(function(){
		var formData = new FormData($("#registrar")[0]);
		$.ajax({
			url  : 'db/registrar.php',
			type : 'POST',
			contentType: false,
			processData: false,
			data: formData,
			beforeSend: function(){
				$("#error").fadeOut();
				$("#error").fadeIn(100, function(){
					$(".error").html('');
					$(".error").html('<div class="alert alert-warning" role="alert"> Cargando ... </div>');
				});
			},
			success : function(response){
				if(response=="1"){
					$("#error").fadeIn(100, function(){
						$(".error").html('');
						$(".error").html('<div class="alert alert-success" role="alert"> El usuario se registró con éxito. </div>');
						$("#register4").addClass("hidden");
						$("#home").removeClass("hidden");
						$("#page").attr("src","./estruc/maps/index.php");
						location.href='index.php';
					});
				}else{
					$("#btn-login").html('Error');
					$("#error").fadeIn(100, function(){
						$(".error").html('');
						$(".error").html('<div class="alert alert-danger" role="alert"> '+response+' </div>');
					});
				}
		   }
		});
		return false;
	});
});