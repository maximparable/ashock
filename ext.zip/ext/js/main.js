$(document).ready(function() {
  // variables
	"use strict";
	
	var	trigger = $('.hamburger'), overlay = $('.overlay'), isClosed = false;
	
	var campo1=0;
	var campo2=0;
	var campo3=0;
	var campo4=0;
	var campo5=0;
	var campo6=0;
	var campo7=0;
	var campo8=0;
	var campo9=0;
	var campo10=0;
	var campo11=0;
	
    trigger.click(function () {
      hamburger_cross();      
    });
    function hamburger_cross() {
      if (isClosed === true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = true;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
	$('#wrapper').toggleClass('toggled');
  });	
	/**************************************************/
  $("#registro").click(function () {
	$("#register-login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#btn-registrar-usuario").click(function () {
	/*
	$.ajax({
		   url  : './estruc/register-users.php',
   		success : function(register_users){
			$("#registrar-usuario").append(register_users);
		}
	});
	*/
	$("#register-clients").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#btn-registrar-taller").click(function () {
	/*$.ajax({
		   url  : './estruc/register-taller.php',
   		success : function(register_taller){
			$("#register-taller").append(register_taller);
		}
	});*/
	$("#register-clients").addClass("hidden");
	$("#taller1").removeClass("hidden");
  });
  $("#btn-registrar-grua").click(function () {
	/*$.ajax({
		   url  : './estruc/register-grua.php',
   		success : function(register_grua){
			$("#register-grua").append(register_grua);
		}
	});*/
	$("#register-clients").addClass("hidden");
	$("#grua1").removeClass("hidden");
  });
  $("#regresar0").click(function () {
	$("#register-clients").addClass("hidden");
	$("#register-login").removeClass("hidden");
  });
  $("#regresar1").click(function () {
	$("#register1").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar2").click(function () {
	$("#register2").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#regresar3").click(function () {
	$("#register3").addClass("hidden");
	$("#register2").removeClass("hidden");
  });
  $("#regresar4").click(function () {
	$("#register4").addClass("hidden");
	$("#register3").removeClass("hidden");
  });
  $("#regresar_taller1").click(function () {
	$("#taller1").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar_taller2").click(function () {
	$("#taller2").addClass("hidden");
	$("#taller1").removeClass("hidden");
  });
  $("#regresar_taller3").click(function () {
	$("#taller3").addClass("hidden");
	$("#taller2").removeClass("hidden");
  });
  $("#regresar_grua1").click(function () {
	$("#grua1").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar_grua2").click(function () {
	$("#grua2").addClass("hidden");
	$("#grua1").removeClass("hidden");
  });
  $("#regresar_grua3").click(function () {
	$("#grua3").addClass("hidden");
	$("#grua2").removeClass("hidden");
  });
	
  $("#siguiente1").click(function () {
	if($("#cedula").val()==""){
		$("#cedula").css("border","1px solid #A92121");
	}else{
		$("#cedula").css("border","1px solid #ccc");
		campo1=1;
	}
	if($("#placa").val()==""){
		$("#placa").css("border","1px solid #A92121");
	}else{
		$("#placa").css("border","1px solid #ccc");
		campo2=1;
	}
	if($("#nombres").val()==""){
		$("#nombres").css("border","1px solid #A92121");
	}else{
		$("#nombres").css("border","1px solid #ccc");
		campo3=1;
	}
	if($("#apellidos").val()==""){
		$("#apellidos").css("border","1px solid #A92121");
	}else{
		$("#apellidos").css("border","1px solid #ccc");
		campo4=1;
	}
	if($("#correo").val()==""){
		$("#correo").css("border","1px solid #A92121");
	}else{
		$("#correo").css("border","1px solid #ccc");
		campo5=1;
	}
	if($("#contrasena").val()==""){
		$("#contrasena").css("border","1px solid #A92121");
	}else{
		$("#contrasena").css("border","1px solid #ccc");
		campo6=1;
	}
	if($("#telefono").val()==""){
		$("#telefono").css("border","1px solid #A92121");
	}else{
		$("#telefono").css("border","1px solid #ccc");
		campo7=1;
	}var total=campo1+campo2+campo3+campo4+campo5+campo6+campo7;
	if(total==7){
		$("#register1").addClass("hidden");
		$("#register2").removeClass("hidden");
	}
	  /*
		
	  */
  });
  $("#siguiente2").click(function () {
	if($("#tipo_vehiculo").val()==0){
		$("#tipo_vehiculo").css("border","1px solid #A92121");
	}else{
		$("#tipo_vehiculo").css("border","1px solid #ccc");
		campo8=1;
	}
	if($("#fabricante").val()==0){
		$("#fabricante").css("border","1px solid #A92121");
	}else{
		$("#fabricante").css("border","1px solid #ccc");
		campo9=1;
	}
	if($("#modelos").val()==0){
		$("#modelos").css("border","1px solid #A92121");
	}else{
		$("#modelos").css("border","1px solid #ccc");
		campo10=1;
	}
	if($("#anos").val()==0){
		$("#anos").css("border","1px solid #A92121");
	}else{
		$("#anos").css("border","1px solid #ccc");
		campo11=1;
	}var total2=campo8+campo9+campo10+campo11;
	if(total2==4){
		$("#register2").addClass("hidden");
		$("#register3").removeClass("hidden");
	}
  });
  $("#siguiente3").click(function () {
	$("#register3").addClass("hidden");
	$("#register4").removeClass("hidden");
	$("#taller3").addClass("hidden");
	$("#taller4").removeClass("hidden");
	$("#grua3").addClass("hidden");
	$("#grua4").removeClass("hidden");
  });
	
  $("#siguiente_taller1").click(function () {
	$("#taller1").addClass("hidden");
	$("#taller2").removeClass("hidden");
  });
  $("#siguiente_taller2").click(function () {
	$("#taller2").addClass("hidden");
	$("#taller3").removeClass("hidden");
  });
	
  $("#siguiente_grua1").click(function () {
	$("#grua1").addClass("hidden");
	$("#grua2").removeClass("hidden");
  });
  $("#siguiente_grua2").click(function () {
	$("#grua2").addClass("hidden");
	$("#grua3").removeClass("hidden");
  });
	/**************************************************/
  $("#ingreso").click(function () {
	$("#register-login").addClass("hidden");
	$("#login").removeClass("hidden");
  });
  $("#login footer h5 a").click(function () {
	$("#login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
	/**************************************************/
  $("#taller").click(function () {
	var r = confirm("En este momento usted está solicitando una cita al taller más cercano");
	if (r == true) {
		alert("En este momento el servicio de carro taller no esta disponible");
	} else {
	    txt = "Error!";
	}
  });
  $("#asistente").click(function () {
	alert("En este momento el servicio de croquis no esta disponible");
  });
  $("#grua").click(function () {
	var r = confirm("Servicio de asistente de choque no disponible");
	if (r == true) {
		alert("Buscando gruas...");
		alert("En este momento el servicio de carro taller no esta disponible");
	} else {
	    txt = "Error!";
	}
  });
  $("#grua_u").click(function () {
	alert("No se han creado solicitudes para mostrar");
  });
  $("#micuenta").click(function () {
	$("#home").addClass("hidden");
	$("#cuenta").removeClass("hidden");
	$("#micuenta1").removeClass("hidden");
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#historia").click(function () {
	alert("Sin historia disponible");
  });
  $(".ayuda").click(function () {
	alert("Servicio de ayuda no disponible");
  });
  $(".cerrar").click(function () {
		$.ajax({
			   url  : './db/salir.php',
   			success : function(salir){
				$("body").append(salir);
				$("#home").addClass("hidden");
				$("#register-login").removeClass("hidden");
				hamburger_cross();
				$('#wrapper').toggleClass('toggled');
				location.href='index.php';
			}
		});
  });
	/**************************************************/
  $(".return-chat").click(function () {
	$("#home").removeClass("hidden");
	$("#chat_car").addClass("hidden");
	$("#cuenta").addClass("hidden");
  });
  $("#btn-chat").click(function () {
	$("#home").addClass("hidden");
	$("#chat_car").removeClass("hidden");
  });
	/**************************************************/
	
	/**************************************************/
  $("#personal").click(function () {
	$("#micuenta1").removeClass("hidden");
	$("#micuenta2").addClass("hidden");
	$("#micuenta3").addClass("hidden");
  });
  $("#vehiculo").click(function () {
	$("#micuenta1").addClass("hidden");
	$("#micuenta2").removeClass("hidden");
	$("#micuenta3").addClass("hidden");
  });
  $("#fotos").click(function () {
	$("#micuenta1").addClass("hidden");
	$("#micuenta2").addClass("hidden");
	$("#micuenta3").removeClass("hidden");
  });
	/**************************************************/
  $("#pcontrol").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#usuarios").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#chat").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#roles").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#talleres").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#gruas").click(function () {
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
});