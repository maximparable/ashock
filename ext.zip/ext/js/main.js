$(document).ready(function() {
  // variables
	"use strict";
	
	var	trigger = $('.hamburger'), overlay = $('.overlay'), isClosed = false;
    trigger.click(function () {
      hamburger_cross();      
    });
    function hamburger_cross() {
      if (isClosed === true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = true;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
  });	
	/**************************************************/
  $("#registro").click(function () {
	$("#register-login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#registrar-usuario").click(function () {
	$("#register-clients").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#regresar0").click(function () {
	$("#register-clients").addClass("hidden");
	$("#register-login").removeClass("hidden");
  });
  $("#regresar1").click(function () {
	$("#register1").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar2").click(function () {
	$("#register2").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#regresar3").click(function () {
	$("#register3").addClass("hidden");
	$("#register2").removeClass("hidden");
  });
  $("#regresar4").click(function () {
	$("#register4").addClass("hidden");
	$("#register3").removeClass("hidden");
  });
	
  var campo1=0;
  var campo2=0;
  var campo3=0;
  var campo4=0;
  var campo5=0;
  var campo6=0;
  var campo7=0;
  var campo8=0;
  var campo9=0;
  var campo10=0;
  var campo11=0;
	
  $(".siguiente1").click(function () {
	if($("#cedula").val()==""){
		$("#cedula").css("border","1px solid #A92121");
	}else{
		$("#cedula").css("border","1px solid #ccc");
		campo1=1;
	}
	if($("#placa").val()==""){
		$("#placa").css("border","1px solid #A92121");
	}else{
		$("#placa").css("border","1px solid #ccc");
		campo2=1;
	}
	if($("#nombres").val()==""){
		$("#nombres").css("border","1px solid #A92121");
	}else{
		$("#nombres").css("border","1px solid #ccc");
		campo3=1;
	}
	if($("#apellidos").val()==""){
		$("#apellidos").css("border","1px solid #A92121");
	}else{
		$("#apellidos").css("border","1px solid #ccc");
		campo4=1;
	}
	if($("#correo").val()==""){
		$("#correo").css("border","1px solid #A92121");
	}else{
		$("#correo").css("border","1px solid #ccc");
		campo5=1;
	}
	if($("#contrasena").val()==""){
		$("#contrasena").css("border","1px solid #A92121");
	}else{
		$("#contrasena").css("border","1px solid #ccc");
		campo6=1;
	}
	if($("#telefono").val()==""){
		$("#telefono").css("border","1px solid #A92121");
	}else{
		$("#telefono").css("border","1px solid #ccc");
		campo7=1;
	}var total=campo1+campo2+campo3+campo4+campo5+campo6+campo7;
	if(total==7){
		$("#register1").addClass("hidden");
		$("#register2").removeClass("hidden");
	}
	  /*
		
	  */
  });
  $(".siguiente2").click(function () {
	if($("#tipo_vehiculo").val()==0){
		$("#tipo_vehiculo").css("border","1px solid #A92121");
	}else{
		$("#tipo_vehiculo").css("border","1px solid #ccc");
		campo8=1;
	}
	if($("#fabricante").val()==0){
		$("#fabricante").css("border","1px solid #A92121");
	}else{
		$("#fabricante").css("border","1px solid #ccc");
		campo9=1;
	}
	if($("#modelos").val()==0){
		$("#modelos").css("border","1px solid #A92121");
	}else{
		$("#modelos").css("border","1px solid #ccc");
		campo10=1;
	}
	if($("#anos").val()==0){
		$("#anos").css("border","1px solid #A92121");
	}else{
		$("#anos").css("border","1px solid #ccc");
		campo11=1;
	}var total2=campo8+campo9+campo10+campo11;
	if(total2==4){
		$("#register2").addClass("hidden");
		$("#register3").removeClass("hidden");
	}
  });
  $(".siguiente3").click(function () {
	$("#register3").addClass("hidden");
	$("#register4").removeClass("hidden");
  });
	/**************************************************/
  $("#ingreso").click(function () {
	$("#register-login").addClass("hidden");
	$("#login").removeClass("hidden");
  });
  $("#login footer h5 a").click(function () {
	$("#login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
	/**************************************************/
  $("#taller").click(function () {
	alert("Servicio de taller no disponible");
  });
  $("#asistente").click(function () {
	alert("Servicio de asistente de choque no disponible");
  });
  $("#grua").click(function () {
	alert("Servicio de grúa no disponible");
  });
  $("#micuenta").click(function () {
	$("#home").addClass("hidden");
	$("#cuenta").removeClass("hidden");
	$("#micuenta1").removeClass("hidden");
	$("#page").attr("src","");
	hamburger_cross();
	$('#wrapper').toggleClass('toggled');
  });
  $("#historia").click(function () {
	alert("Sin historia disponible");
  });
  $(".ayuda").click(function () {
	alert("Servicio de ayuda no disponible");
  });
  $(".cerrar").click(function () {
		$.ajax({
			   url  : './db/salir.php',
   			success : function(salir){
				$("body").append(salir);
				$("#home").addClass("hidden");
				$("#register-login").removeClass("hidden");
				hamburger_cross();
				$('#wrapper').toggleClass('toggled');
			}
		});
  });
	/**************************************************/
  $("#return-chat").click(function () {
	$("#home").removeClass("hidden");
	$("#chat").addClass("hidden");
	$("#page").attr("src","./estruc/maps/index.php");
  });
  $("#btn-chat").click(function () {
	$("#home").addClass("hidden");
	$("#chat").removeClass("hidden");
	$("#page").attr("src","");
  });
	/**************************************************/
	
	/**************************************************/
});