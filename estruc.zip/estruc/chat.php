					<input id="logined" type="number" value="<?php echo $login; ?>" style="display:none">
					<input id="chatnombres" type="text" value="<?php echo $nombres; ?>" style="display:none">
					<input id="chatapellidos" type="text" value="<?php echo $apellidos; ?>" style="display:none">
					<input id="chatcorreo" type="text" value="<?php echo $correo; ?>" style="display:none">
					<input id="chatfoto_perfil" type="text" value="<?php echo $foto_perfil; ?>" style="display: none">
					<header>
						<div class="header-top clearfix">
							<a class="l-left toggle-menu" href="#">
								<p style="color: #FFFFFF; font-size: 26px; line-height: 59px">
									<i class="fa fa-arrow-left return-chat" style="color: #FFFFFF; font-size: 26px; line-height: 59px"></i>
									<img id="chatfoto" src="img/perfil/users/sin_foto.png" width="45" alt=""> <label id="chatusername">usuario</label><span id="estado"></span>
								</p>
							</a>
							<a class="l-right toggle-massage" href="#">
							  <i class="fa fa-comment"></i>
							</a>
						</div>
					</header>
					<div id="fullpage2" style="background: linear-gradient(180deg, #ffffff, #CFCFCF); padding: 60px 30px;">
						<!-- script -->
					</div>
					<audio id="audio" class="hidden">
						<source type="audio/mp3" src="sound/sms.mp3">
						<source type="audio/ogg" src="sound/sms.ogg">
						<source type="audio/aac" src="sound/sms.aac">
						<source type="audio/wav" src="sound/sms.wav">
					</audio>
					<footer class="desktop" style="background: #FFFFFF; padding: 8px 20px; box-shadow: 0px 0px 0px 0px #000">
						<p align="center">
							<label for="chat_up_file" style="cursor: pointer; float: left">
								<i class="fa fa-plus" style="padding: 9px; font-size: 24px; color: #FFFFFF; background-color: #0076D6; border-radius: 100%;"></i>
							</label>
							<input id="chat_up_file" type="file" name="foto" style="display: none; cursor: pointer !important;">
							<input id="message" class="message" type="text" name="message" placeholder="Escribir mensaje ..." style="margin-top: 8px; cursor: pointer !important; font-size: 26px; border: 0px; width: 60%;">
							<i class="fa fa-send" style="padding: 15px; font-size: 28px; color: #0076D6; background: none; border-radius: 100%; float: right;"></i>
						</p>
					</footer>