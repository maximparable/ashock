
						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<form id="logear" action="" method="post" enctype="multipart/form-data">
							  <fieldset>
								<div class="form-group">
									<i class="fa fa-envelope"></i>
									<input type="text" id="usuario" class="form-box" name="usuario" placeholder="micorreo@empresa.com">
								</div>
								<div class="form-group">
									<i class="fa fa-lock" style="font-size: 42px"></i>
									<input type="password" id="password" class="form-box" name="clave" placeholder="Contraseña123">
								</div>
								<div class="login_response"></div>
								<button id="entrar" type="button" class="btn btn-warning">Entrar</button>
							  </fieldset>
							</form>
						</div>
						<footer style="background: #ffffff"><br>
							<h5 align="center">Eres nuevo <a href="#" style="color: #7700A8">Regístrare</a></h5>
						</footer>