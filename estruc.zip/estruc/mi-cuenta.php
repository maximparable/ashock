			<section class="regular slider">
				<div>
					<div><h3 role="presentation" aria-controls="navigation01" id="slick-slide01">Registro Personal</h3></div>
				</div>
				<div>
					<div role="presentation" aria-controls="navigation02" id="slick-slide02"><h3>Registro del Vehículo</h3></div>
				</div>
				<div>
					<div role="presentation" aria-controls="navigation03" id="slick-slide03"><h3>Fotografías  del Vehículo</h3></div>
				</div>
			</section>
					<div id="micuenta1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente1"></i>
								</h2>
							</div>
						</header>
						<div class="container">
								<div class="form-group">
									<p align="center">
										<label for="imagen6" style="cursor: pointer">
											<img id="foto6" src="<?php echo $foto_perfil; ?>" width="92" alt="">
										</label>
										<input id="imagen6" type="file" name="foto_perfil" style="display: none; cursor: pointer !important;">
									</p>
								</div>
								<div class="form-group">
									<label class="control-label" for="cedula">Cédula *</label>
									<input type="number" class="form-control" id="cedula2" name="cedula" value="<?php echo $cedula; ?>" required>
								</div>
								<div class="form-group">
									<label class="control-label" for="placa">Placa del Vehículo *</label>
									<input type="text" class="form-control" id="placa2" name="placa" value="<?php echo $placa; ?>" required>
								</div>
								<div class="form-group">
									<label class="control-label" for="nombres">Nombres *</label>
									<input type="text" class="form-control" id="nombres2" name="nombres" value="<?php echo $nombres; ?>" required>
								</div>
								<div class="form-group">
									<label class="control-label" for="apellidos">Apellidos *</label>
									<input type="text" class="form-control" id="apellidos2" name="apellidos" value="<?php echo $apellidos; ?>" required>
								</div>
								<div class="form-group">
									<label class="control-label" for="correo">Correo Electrónico *</label>
									<input type="text" class="form-control" id="correo2" name="correo" value="<?php echo $correo; ?>" required>
								</div>
								<div class="form-group">
									<label class="control-label" for="contrasena">Contraseña *</label>
									<input type="password" class="form-control" id="contrasena2" name="contrasena" value="<?php echo $contrasena; ?>" required>
								</div>
								<div class="form-group">
									<label class="control-label" for="telefono">Numero de contacto *</label>
									<input type="number" class="form-control" id="telefono2" name="telefono" value="<?php echo $telefono; ?>" required>
								</div>
								<button id="siguiente1" type="button" class="btn btn-warning siguiente1">Siguiente</button>
							
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar1" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="micuenta2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente2"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<br><br><br>
								<div class="form-group">
									<label class="control-label" for="">Tipo de Vehículo*</label>
									<select id="tipo_vehiculo" name="tipo_vehiculo" class="form-control">
										<option value="<?php echo $id_tipo_car; ?>"><?php echo $tipo_car; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Fabricante del Vehículo*</label>
									<select id="fabricante" name="fabricante" class="form-control">
										<option value="<?php echo $id_fabricante; ?>"><?php echo $fabricante; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Modelo del Vehículo *</label>
									<select id="modelos" name="modelos" class="form-control">
										<option value="<?php echo $id_modelos; ?>"><?php echo $modelos; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Año de Fabricación  del vehículo *</label>
									<select id="anos" name="anos" class="form-control">
										<option value="<?php echo $id_anos; ?>"><?php echo $anos; ?></option>
									</select>
								</div>
								<button id="siguiente2" type="button" class="btn btn-warning siguiente2">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar2" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="micuenta3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente3"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br>
								<div class="form-group">
									<label class="control-label" for="">Fotografía vista frontal del vehículo *</label><br/>
									<label for="imagen2" style="cursor: pointer">
										<img id="foto2" src="<?php echo $foto_frontal; ?>" alt="">
									</label>
									<input id="imagen2" type="file" name="foto_frontal" style="display: none; cursor: pointer !important;">
								</div>
								<div class="form-group">
									<label class="control-label" for="">Fotografía perfil lateral derecho *</label><br/>
									<label for="imagen3" style="cursor: pointer">
										<img id="foto3" src="<?php echo $foto_derecha; ?>" alt="">
									</label>
									<input id="imagen3" type="file" name="foto_derecha" style="display: none; cursor: pointer !important;">
								</div>
								<div class="form-group">
									<label class="control-label" for="">Fotografía vista trasera del vehículo *</label><br/>
									<label for="imagen4" style="cursor: pointer">
										<img id="foto4" src="<?php echo $foto_trasera; ?>" alt="">
									</label>
									<input id="imagen4" type="file" name="foto_izquierda" style="display: none; cursor: pointer !important;">
								</div>
								<div class="form-group">
									<label class="control-label" for="">Fotografía perfil lateral izquierdo *</label><br/>
									<label for="imagen5" style="cursor: pointer">
										<img id="foto5" src="<?php echo $foto_izquierda; ?>" alt="">
									</label>
									<input id="imagen5" type="file" name="foto_trasera" style="display: none; cursor: pointer !important;">
								</div>
								<button id="siguiente3" type="button" class="btn btn-warning siguiente3">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar3" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

			  <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
			  <script src="./ext/js/slick.js" type="text/javascript" charset="utf-8"></script>
			  <script type="text/javascript">
				$(document).on('ready', function() {
				  $(".regular").slick({
					dots: true,
					infinite: true,
					variableWidth: true,
				  });
				});
			</script>