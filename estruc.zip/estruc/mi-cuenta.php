				<ul class="menu-micuena">
					<li>
						<h3>Registro Personal</h3>
					</li>
					<li>
						<h3>Registro del Vehículo</h3>
					</li>
					<li>
						<h3>Fotografías  del Vehículo</h3>
					</li>
				</ul><br><br>
					<div id="micuenta1" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente1"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<div class="form-group">
								<p align="center">
										<label for="imagen6" style="cursor: pointer">
											<img id="foto6" src="<?php echo $foto_perfil; ?>" width="92" alt="">
										</label>
										<input id="imagen6" type="file" name="foto_perfil" style="display: none; cursor: pointer !important;">
									</p>
							</div>
							<div class="form-group">
									<label class="control-label" for="cedula">Cédula *</label>
									<input type="number" class="form-control" id="cedula2" name="cedula2" value="<?php echo $cedula; ?>" required>
								</div>
							<div class="form-group">
									<label class="control-label" for="placa">Placa del Vehículo *</label>
									<input type="text" class="form-control" id="placa2" name="placa2" value="<?php echo $placa; ?>" required>
								</div>
							<div class="form-group">
									<label class="control-label" for="nombres">Nombres *</label>
									<input type="text" class="form-control" id="nombres2" name="nombres2" value="<?php echo $nombres; ?>" required>
								</div>
							<div class="form-group">
									<label class="control-label" for="apellidos">Apellidos *</label>
									<input type="text" class="form-control" id="apellidos2" name="apellidos2" value="<?php echo $apellidos; ?>" required>
								</div>
							<div class="form-group">
									<label class="control-label" for="correo">Correo Electrónico *</label>
									<input type="text" class="form-control" id="correo2" name="correo2" value="<?php echo $correo; ?>" required>
								</div>
							<div class="form-group">
									<label class="control-label" for="contrasena">Contraseña *</label>
									<input type="password" class="form-control" id="contrasena2" name="contrasena2" value="<?php echo $contrasena; ?>" required>
								</div>
							<div class="form-group">
									<label class="control-label" for="telefono">Numero de contacto *</label>
									<input type="number" class="form-control" id="telefono2" name="telefono2" value="<?php echo $telefono; ?>" required>
								</div>
							<button id="siguiente1" type="button" class="btn btn-warning siguiente1">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar1" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="micuenta2" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente2"></i>
								</h2>
							</div>
						</header>
						<div class="container">
							<br><br><br>
								<div class="form-group">
									<label class="control-label" for="">Tipo de Vehículo*</label>
									<select id="tipo_vehiculo" name="tipo_vehiculo" class="form-control">
										<option value="<?php echo $id_tipo_car; ?>"><?php echo $tipo_car; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Fabricante del Vehículo*</label>
									<select id="fabricante" name="fabricante" class="form-control">
										<option value="<?php echo $id_fabricante; ?>"><?php echo $fabricante; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Modelo del Vehículo *</label>
									<select id="modelos" name="modelos" class="form-control">
										<option value="<?php echo $id_modelos; ?>"><?php echo $modelos; ?></option>
									</select>
								</div>
								<div class="form-group">
									<label class="control-label" for="">Año de Fabricación  del vehículo *</label>
									<select id="anos" name="anos" class="form-control">
										<option value="<?php echo $id_anos; ?>"><?php echo $anos; ?></option>
									</select>
								</div>
								<button id="siguiente2" type="button" class="btn btn-warning siguiente2">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar2" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>

					<div id="micuenta3" class="hidden">
						<header>
							<div class="header-top clearfix">
								<h2 style="text-align: left; color: #FFFFFF; font-size: 21px">
									Registro Personal 
									<i style="position: relative; top: -5px; cursor: pointer" class="fa fa-check l-right siguiente3"></i>
								</h2>
							</div>
						</header>
						<div class="container"><br>
							<div class="form-group">
								<label class="control-label" for="">Fotografía vista frontal del vehículo *</label><br/>
								<label for="imagen2" style="cursor: pointer">
									<img id="foto2" src="<?php echo $foto_frontal; ?>" alt="">
								</label>
								<input id="imagen2" type="file" name="foto_frontal" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía perfil lateral derecho *</label><br/>
								<label for="imagen3" style="cursor: pointer">
										<img id="foto3" src="<?php echo $foto_derecha; ?>" alt="">
									</label>
								<input id="imagen3" type="file" name="foto_derecha" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía vista trasera del vehículo *</label><br/>
								<label for="imagen4" style="cursor: pointer">
									<img id="foto4" src="<?php echo $foto_trasera; ?>" alt="">
								</label>
								<input id="imagen4" type="file" name="foto_izquierda" style="display: none; cursor: pointer !important;">
							</div>
							<div class="form-group">
								<label class="control-label" for="">Fotografía perfil lateral izquierdo *</label><br/>
								<label for="imagen5" style="cursor: pointer">
									<img id="foto5" src="<?php echo $foto_izquierda; ?>" alt="">
								</label>
								<input id="imagen5" type="file" name="foto_trasera" style="display: none; cursor: pointer !important;">
							</div>
							<button id="siguiente3" type="button" class="btn btn-warning siguiente3">Siguiente</button>
						</div>
						<footer style="background: transparent; height: 30px">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar3" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>
					</div>