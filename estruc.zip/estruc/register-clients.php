						<div class="container">
							<center><img src="img/logo.png" width="45%" alt=""></center>
							<br><h1 align="center">Assistane Shock</h1><br>
							<button id="registrar-usuario" type="button" class="btn btn-warning">Usuario</button>
							<button id="registrar-taller" type="button" class="btn btn-warning">Taller</button>
							<button id="registrar-grua" type="button" class="btn btn-warning">Grua</button>
							<br><h2>Seleccione su Rol</h2><br>
						</div>
						<footer style="background: transparent">
							<i class="fa fa-mail-reply l-left" style="color: #ABABAB; margin-left: 10px"></i> 
							<span id="regresar0" class="l-left" style="color: #ABABAB; margin-left: 10px"> Regresar </span>
						</footer>