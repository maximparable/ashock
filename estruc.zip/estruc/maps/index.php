<!DOCTYPE html>
<html>
	<head>

		<title>Mapa</title>

		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<meta name="description" content="By MCDeveloper." />
		<meta name="keywords"  content="key1,key1,key1" />
		<meta name="Resource-type" content="Document" />
		<meta name="author" content="mcdeveloper" />

    <style type="text/css">
      html, body, #map { height: 100%; margin: 0; }
    </style>
    
		<?php
		require("../../db/consulta_usuario.php");
		?><script src="../../ext/js/jquery-3.1.1.min.js"></script>
  </head>
  <body>
	<div id="map"></div>
  </body>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVHQ-vbUvaGZQUx5MweCwlE8oMwVieIAw&callback=initMap" async defer></script>
    <script type="text/javascript" src="http://localhost:3000/socket.io/socket.io.js"></script>
	<script type="text/javascript" src="js/main-map.js"></script>
</html>