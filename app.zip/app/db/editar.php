<?php
include("session.php");
header('Content-Type: text/html; charset=utf-8');

	$usuario = $_SESSION['usuario'];
	$quey_users =  $db_con->query("SELECT * FROM usuario WHERE usuario='$usuario'");
	$result_users = $quey_users->fetch(PDO::FETCH_ASSOC);

	$id = $result_users["id"];

	$perfil = $_POST["perfil"]; 
	$idciudad = $_POST["idciudad"];
	$nombre1 = $_POST["nombre1"];
	$nombre2 = $_POST["nombre2"];
	$apellido1 = $_POST["apellido1"];
	$apellido2 = $_POST["apellido2"];
	$cedula = $_POST["cedula"];
	$email = $_POST["email"];
	$direccion = $_POST["direccion"]; 
	$telefono = $_POST["telefono"];
	$celular = $_POST["celular"];

	$subir_foto1 = 0;

/*                     ARCHIVO 1                              */
$tamano= $_FILES['foto']['size']; 
if ($tamano>0) {
	$file = $_FILES["foto"];
	$nombre = $file["name"];
	$array_nombre = explode('.',$nombre);
	$cuenta_arr_nombre = count($array_nombre);
	$extension = strtolower($array_nombre[--$cuenta_arr_nombre]);
	$foto = time().'_'.rand(0,99999).'.'.$extension;
    $ruta_provisional = $file["tmp_name"];
    $folder = "../fotos/";
	$destino1 = $folder.$foto;
	$subir_foto1 = 1;
	$reporte = "ok";
	move_uploaded_file($ruta_provisional, $destino1);
}else{
	$foto = $result_users["foto"];
	$reporte = "ok";
}
/*  --------------------------------------------------------- */
	$update = 
				"UPDATE usuario SET 
				perfil = '$perfil', 
				idciudad = '$idciudad', 
				nombre1 = '$nombre1', 
				nombre2 = '$nombre2', 
				apellido1 = '$apellido1', 
				apellido2 = '$apellido1', 
				cedula = '$cedula', 
				email = '$email', 
				direccion = '$direccion', 
				telefono = '$telefono', 
				celular = '$celular', 
				foto = '$foto' 
				WHERE id = $id;"
			;

if ($db_con->query($update)){
	$reporte = '1';
	echo $reporte;	
}else{
	$reporte = '2';
	echo $reporte;	
}

?>