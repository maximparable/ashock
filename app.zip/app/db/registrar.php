<?php
require("conectar.php");
header('Content-Type: text/html; charset=utf-8');
$id = "";

	$cedula = $_POST['cedula'];
	$telefono = $_POST['telefono'];
	$nombres = $_POST['nombres'];
	$apellidos = $_POST['apellidos'];
	$correo = $_POST['correo'];
	$contrasena = $_POST['contrasena'];
	$contrasena = md5($contrasena);
	$placa = $_POST['placa'];
	$id_tipo_car = $_POST['tipo_vehiculo'];
	$id_fabricante = $_POST['fabricante'];
	$id_modelo = $_POST['modelos'];
	$id_ano = $_POST['anos'];

$estado = "activo";
$fecharegistro = date("Y") . "-" . date("m") . "-" . date("d");
$reporte = "error ";
if ($_FILES['foto_perfil']['size']>0) {
	$file = $_FILES["foto_perfil"];
	$nombre = $file["name"];
	$array_nombre = explode('.',$nombre);
	$cuenta_arr_nombre = count($array_nombre);
	$extension = strtolower($array_nombre[--$cuenta_arr_nombre]);
	$foto = time().'_'.rand(0,99999).'.'.$extension;
    $foto_perfil = "./img/perfil/users/".$foto;
	move_uploaded_file($file["tmp_name"], "../img/perfil/users/".$foto);
}else{$foto_perfil = "./img/perfil/users/sin_foto.png";}


if ($_FILES['foto_frontal']['size']>0) {
	$file2 = $_FILES["foto_frontal"];
	$nombre2 = $file2["name"];
	$array_nombre2 = explode('.',$nombre2);
	$cuenta_arr_nombre2 = count($array_nombre2);
	$extension2 = strtolower($array_nombre2[--$cuenta_arr_nombre2]);
	$foto2 = time().'_'.rand(0,99999).'.'.$extension2;
    $foto_frontal = "./img/vehiculos/carros/".$foto2;
	move_uploaded_file($file2["tmp_name"], "../img/vehiculos/carros/".$foto2);
}else{$foto_frontal = "./img/vehiculos/carros/sin-carro.jpg";}

if ($_FILES['foto_derecha']['size']>0) {
	$file3 = $_FILES["foto_derecha"];
	$nombre3 = $file3["name"];
	$array_nombre3 = explode('.',$nombre3);
	$cuenta_arr_nombre3 = count($array_nombre3);
	$extension3 = strtolower($array_nombre3[--$cuenta_arr_nombre3]);
	$foto3 = time().'_'.rand(0,99999).'.'.$extension3;
    $foto_derecha = "./img/vehiculos/carros/".$foto3;
	move_uploaded_file($file3["tmp_name"], "../img/vehiculos/carros/".$foto3);
}else{$foto_derecha = "./img/vehiculos/carros/sin-carro.jpg";}

if ($_FILES['foto_izquierda']['size']>0) {
	$file4 = $_FILES["foto_izquierda"];
	$nombre4 = $file4["name"];
	$array_nombre4 = explode('.',$nombre4);
	$cuenta_arr_nombre4 = count($array_nombre4);
	$extension4 = strtolower($array_nombre4[--$cuenta_arr_nombre4]);
	$foto4 = time().'_'.rand(0,99999).'.'.$extension4;
    $foto_izquierda = "./img/vehiculos/carros/".$foto4;
	move_uploaded_file($file4["tmp_name"], "../img/vehiculos/carros/".$foto4);
}else{$foto_izquierda = "./img/vehiculos/carros/sin-carro.jpg";}

if ($_FILES['foto_trasera']['size']>0) {
	$file5 = $_FILES["foto_trasera"];
	$nombre5 = $file5["name"];
	$array_nombre5 = explode('.',$nombre5);
	$cuenta_arr_nombre5 = count($array_nombre5);
	$extension5 = strtolower($array_nombre[--$cuenta_arr_nombre5]);
	$foto5 = time().'_'.rand(0,99999).'.'.$extension5;
    $foto_trasera = "./img/vehiculos/carros/".$foto5;
	move_uploaded_file($file5["tmp_name"], "../img/vehiculos/carros/".$foto5);
}else{$foto_trasera = "./img/vehiculos/carros/sin-carro.jpg";}

	$error1=0;
	$error2=0;
	$INSERT_carros = "INSERT INTO carros (placa, id_tipo_car, id_fabricante, id_modelo, id_ano, foto_frontal, foto_derecha, foto_izquierda, foto_trasera)
	VALUES ('$placa', $id_tipo_car, $id_fabricante, $id_modelo, $id_ano, '$foto_frontal', '$foto_derecha', '$foto_izquierda', '$foto_trasera')";
	
	$id_car = 0;
	if ($db_con->query($INSERT_carros)){
		$error1=1;
		$query_carros = $db_con->query("SELECT * FROM carros ORDER BY id_car DESC");
		$carros = $query_carros->fetch(PDO::FETCH_ASSOC);
		$id_car = $carros['id_car'];
	}else{
		$id_car = 0;
	}

	$INSERT_users = "INSERT INTO users (id_u, id_car, cedula, telefono, nombres, apellidos, correo, contrasena, foto_perfil, estado) 
	VALUES (NULL, '$id_car', '$cedula', '$telefono', '$nombres', '$apellidos', '$correo', '$contrasena', '$foto_perfil', '$estado')";
	if ($db_con->query($INSERT_users)){
		$error2=1;
	}
$reporte = $error1+$error2;
	if ($reporte==2){
		@session_start();
		$_SESSION['cedula'] = $cedula;
		echo 1;
	}else{
		echo $reporte;
	}
?>