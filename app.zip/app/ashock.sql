-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 16-10-2018 a las 18:54:58
-- Versión del servidor: 10.1.35-MariaDB
-- Versión de PHP: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `ashock`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `anos`
--

CREATE TABLE `anos` (
  `id_ano` int(11) NOT NULL,
  `ano` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `anos`
--

INSERT INTO `anos` (`id_ano`, `ano`) VALUES
(1, 2001),
(2, 2002),
(3, 2003),
(4, 2004),
(5, 2005),
(6, 2006),
(7, 2007),
(8, 2008),
(9, 2009),
(10, 2010),
(11, 2011),
(12, 2012),
(13, 2013),
(14, 2014),
(15, 2015),
(16, 2016),
(17, 2017),
(18, 2018);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carros`
--

CREATE TABLE `carros` (
  `id_car` int(11) NOT NULL,
  `placa` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id_tipo_car` int(11) NOT NULL,
  `id_fabricante` int(11) NOT NULL,
  `id_modelo` int(11) NOT NULL,
  `id_ano` int(11) NOT NULL,
  `foto_frontal` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `foto_derecha` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `foto_izquierda` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `foto_trasera` varchar(1000) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `carros`
--

INSERT INTO `carros` (`id_car`, `placa`, `id_tipo_car`, `id_fabricante`, `id_modelo`, `id_ano`, `foto_frontal`, `foto_derecha`, `foto_izquierda`, `foto_trasera`) VALUES
(1, 'bbb-321', 8, 1, 1, 3, './img/vehiculos/carros/1536781334_85914.jpg', './img/vehiculos/carros/1536781334_46790.jpg', './img/vehiculos/carros/1536781334_22912.jpg', './img/vehiculos/carros/1536781334_11068.com_'),
(2, 'aaa-123', 8, 4, 5, 15, './img/vehiculos/carros/1536804522_24032.jpg', './img/vehiculos/carros/1536804522_30689.jpg', './img/vehiculos/carros/1536804522_20109.jpg', './img/vehiculos/carros/1536804522_72390.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `fabricantes`
--

CREATE TABLE `fabricantes` (
  `id_fabricante` int(11) NOT NULL,
  `fabricante` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `fabricantes`
--

INSERT INTO `fabricantes` (`id_fabricante`, `fabricante`) VALUES
(1, 'AUDI'),
(2, 'BMW'),
(3, 'CHEVROLET'),
(4, 'FERRARI'),
(5, 'HYUNDAI'),
(6, 'LAMBORGHINI');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modelos`
--

CREATE TABLE `modelos` (
  `id_modelo` int(11) NOT NULL,
  `modelo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `id_fabricante` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `modelos`
--

INSERT INTO `modelos` (`id_modelo`, `modelo`, `id_fabricante`) VALUES
(1, 'A8', 1),
(2, 'SQ7', 1),
(3, 'TTS', 1),
(4, 'SERIE 7', 2),
(5, 'X5', 2),
(6, 'Z4', 2),
(7, 'CRUZE', 3),
(8, 'SPARK', 3),
(9, 'CAMARO', 3),
(10, '488', 4),
(11, 'GTC4', 4),
(12, 'CALIFORNIA', 4),
(13, 'F12', 5),
(14, 'VELOSTER', 5),
(15, 'GENESIS', 5),
(16, 'KONA', 5),
(17, 'AVENTADOR', 6),
(18, 'HURACÁN', 6),
(19, 'MURCÍELAGO', 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos`
--

CREATE TABLE `tipos` (
  `id_tipo_car` int(11) NOT NULL,
  `tipo_car` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `tipos`
--

INSERT INTO `tipos` (`id_tipo_car`, `tipo_car`) VALUES
(1, 'Bus'),
(2, 'Camion'),
(3, 'Camioneta'),
(4, 'Grua'),
(5, 'Furgoneta'),
(8, 'Particular'),
(9, 'Taxi'),
(10, 'Tractor'),
(12, 'Otro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id_u` int(11) NOT NULL,
  `id_car` int(11) NOT NULL,
  `cedula` int(11) NOT NULL,
  `telefono` bigint(20) NOT NULL,
  `nombres` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `apellidos` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `correo` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `contrasena` varchar(100) COLLATE utf8_bin DEFAULT NULL,
  `foto_perfil` varchar(1000) COLLATE utf8_bin DEFAULT NULL,
  `estado` varchar(100) COLLATE utf8_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id_u`, `id_car`, `cedula`, `telefono`, `nombres`, `apellidos`, `correo`, `contrasena`, `foto_perfil`, `estado`) VALUES
(1, 1, 1010199194, 3165398393, 'MIGUEL ANTONIO', 'CASTILLO', 'xxsumperxx@gmail.com', '0fd9cfe8285d3345b1913754371c1b2b', './img/perfil/users/1536781334_46190.jpg', 'activo'),
(2, 2, 1010199188, 3165398393, 'FRANCO', 'ESCAMILLA', 'maxteer_36@hotmail.com', '858ef73565437f09e5d87bc3994683e9', './img/perfil/users/1536804522_60507.jpg', 'activo');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `anos`
--
ALTER TABLE `anos`
  ADD PRIMARY KEY (`id_ano`);

--
-- Indices de la tabla `carros`
--
ALTER TABLE `carros`
  ADD PRIMARY KEY (`id_car`),
  ADD KEY `id_tipo_car` (`id_tipo_car`),
  ADD KEY `id_fabricante` (`id_fabricante`),
  ADD KEY `id_ano` (`id_ano`),
  ADD KEY `id_modelo` (`id_modelo`);

--
-- Indices de la tabla `fabricantes`
--
ALTER TABLE `fabricantes`
  ADD PRIMARY KEY (`id_fabricante`);

--
-- Indices de la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD PRIMARY KEY (`id_modelo`),
  ADD KEY `id_fabricante` (`id_fabricante`);

--
-- Indices de la tabla `tipos`
--
ALTER TABLE `tipos`
  ADD PRIMARY KEY (`id_tipo_car`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_u`),
  ADD UNIQUE KEY `cedula` (`cedula`),
  ADD KEY `id_car` (`id_car`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `anos`
--
ALTER TABLE `anos`
  MODIFY `id_ano` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `carros`
--
ALTER TABLE `carros`
  MODIFY `id_car` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `fabricantes`
--
ALTER TABLE `fabricantes`
  MODIFY `id_fabricante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `modelos`
--
ALTER TABLE `modelos`
  MODIFY `id_modelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT de la tabla `tipos`
--
ALTER TABLE `tipos`
  MODIFY `id_tipo_car` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id_u` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `carros`
--
ALTER TABLE `carros`
  ADD CONSTRAINT `carros_ibfk_1` FOREIGN KEY (`id_tipo_car`) REFERENCES `tipos` (`id_tipo_car`),
  ADD CONSTRAINT `carros_ibfk_2` FOREIGN KEY (`id_fabricante`) REFERENCES `fabricantes` (`id_fabricante`),
  ADD CONSTRAINT `carros_ibfk_3` FOREIGN KEY (`id_modelo`) REFERENCES `modelos` (`id_modelo`),
  ADD CONSTRAINT `carros_ibfk_4` FOREIGN KEY (`id_ano`) REFERENCES `anos` (`id_ano`);

--
-- Filtros para la tabla `modelos`
--
ALTER TABLE `modelos`
  ADD CONSTRAINT `modelos_ibfk_1` FOREIGN KEY (`id_fabricante`) REFERENCES `fabricantes` (`id_fabricante`);

--
-- Filtros para la tabla `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`id_car`) REFERENCES `carros` (`id_car`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
