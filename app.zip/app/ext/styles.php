		<link rel="icon" href="../favicon.ico" type="image/x-icon">
		<link href="./ext/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
		<link rel="stylesheet" type="text/css" href="ext/css/font-awesome.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/estructure.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/style.css" />
		<link rel="stylesheet" type="text/css" href="ext/css/responsive.css" />