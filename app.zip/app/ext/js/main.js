$(document).ready(function() {
  // variables
	"use strict";
	
	var	trigger = $('.hamburger'), overlay = $('.overlay'), isClosed = false;
    trigger.click(function () {
      hamburger_cross();      
    });
    function hamburger_cross() {
      if (isClosed === true) {          
        overlay.hide();
        trigger.removeClass('is-open');
        trigger.addClass('is-closed');
        isClosed = false;
      } else {   
        overlay.show();
        trigger.removeClass('is-closed');
        trigger.addClass('is-open');
        isClosed = true;
      }
  }
  
  $('[data-toggle="offcanvas"]').click(function () {
        $('#wrapper').toggleClass('toggled');
  });	
	/**************************************************/
  $("#registro").click(function () {
	$("#register-login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#registrar-usuario").click(function () {
	$("#register-clients").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#regresar0").click(function () {
	$("#register-clients").addClass("hidden");
	$("#register-login").removeClass("hidden");
  });
  $("#regresar1").click(function () {
	$("#register1").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
  $("#regresar2").click(function () {
	$("#register2").addClass("hidden");
	$("#register1").removeClass("hidden");
  });
  $("#regresar3").click(function () {
	$("#register3").addClass("hidden");
	$("#register2").removeClass("hidden");
  });
  $("#regresar4").click(function () {
	$("#register4").addClass("hidden");
	$("#register3").removeClass("hidden");
  });
	
  $(".siguiente1").click(function () {
	$("#register1").addClass("hidden");
	$("#register2").removeClass("hidden");
  });
  $(".siguiente2").click(function () {
	$("#register2").addClass("hidden");
	$("#register3").removeClass("hidden");
  });
  $(".siguiente3").click(function () {
	$("#register3").addClass("hidden");
	$("#register4").removeClass("hidden");
  });
	/**************************************************/
  $("#ingreso").click(function () {
	$("#register-login").addClass("hidden");
	$("#login").removeClass("hidden");
  });
  $("#login footer h5 a").click(function () {
	$("#login").addClass("hidden");
	$("#register-clients").removeClass("hidden");
  });
	/**************************************************/
  $("#taller").click(function () {
	alert("Servicio de taller no disponible");
  });
  $("#asistente").click(function () {
	alert("Servicio de asistente de choque no disponible");
  });
  $("#grua").click(function () {
	alert("Servicio de grúa no disponible");
  });
  $("#micuenta").click(function () {
	alert("No hay cuenta");
  });
  $("#historia").click(function () {
	alert("Sin historia disponible");
  });
  $(".ayuda").click(function () {
	alert("Servicio de ayuda no disponible");
  });
  $(".cerrar").click(function () {
		$.ajax({
			   url  : './db/salir.php',
   			success : function(salir){
				$("body").append(salir);
				$("#home").addClass("hidden");
				$("#register-login").removeClass("hidden");
				hamburger_cross();
				$('#wrapper').toggleClass('toggled');
			}
		});
  });
	/**************************************************/
  $("#return-chat").click(function () {
	$("#home").removeClass("hidden");
	$("#chat").addClass("hidden");
	$("#page").attr("src","maps/index.html");
  });
  $("#btn-chat").click(function () {
	$("#home").addClass("hidden");
	$("#chat").removeClass("hidden");
	$("#page").attr("src","");
  });
	/**************************************************/
	
	/**************************************************/
});